import mysql.connector as m
try:
    code=int(input('Enter BookCode : '))
    nm=input('Enter Book Name : ')
    cat=input('Enter Category of the Book : ')
    au=input('Enter Author Name : ')
    pub=input('Enter Publication of the Book : ')
    edi=input('Enter Edition : ')
    pri=float(input('Enter Book Price : '))
    con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
    curs=con.cursor()
    curs.execute("insert into books values(%d,'%s','%s','%s','%s','%s',%.2f)"%(code,nm,cat,au,pub,edi,pri))
    con.commit()
    print(' New Book is inserted successfully ')
    con.close()
except:
    print('invalid input...can not insert.  please check The Data You Have Entered!. ')
print('THANK YOU.')

