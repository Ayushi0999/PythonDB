import mysql.connector as m 
con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
curs=con.cursor()
curs.execute("select*from books")
data=curs.fetchall()
print(' Record Of All the Books')
#print(data)
for rec in data:
    print(rec)
    con.close()