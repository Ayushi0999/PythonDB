import mysql.connector as m 
cod=int(input('Enter a Book Code to Find Details : '))

con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
curs=con.cursor()

curs.execute("select BookName,Category,Author,Publication,Edition,Price from books where BookCode=%d" %cod)
data=curs.fetchone()

if data:
  
   print('BookName    : %s' %data[0])
   print('Category    : %s' %data[1])
   print('Author    : %s' %data[2])
   print('Publication    : %s' %data[3])
   print('Edition    : %s' %data[4])
   print('Price : %.2f' %data[5])
   print('Book Detail Found')

else:
    print('This Book does not exist in Our Record')
    con.close()