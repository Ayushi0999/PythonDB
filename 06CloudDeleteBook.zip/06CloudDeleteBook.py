import mysql.connector as m 
con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
curs=con.cursor()

cod=int(input('Enter a Book Code to Delete : '))

curs.execute("select BookName,Category,Author,Publication,Edition,Price from books where BookCode=%d" %cod)
data=curs.fetchone()
print(data)

print('-'*30)
if data:
    typ=input('Are You Sure do You Want To Delete This Book ? (YES/NO) :')
    if typ.lower()=='yes':
        curs.execute("delete from books where BookCode=%d" %cod)
        con.commit()
        print('Entered Book Is Deleted successfully')
    elif typ.lower()=='no':
        print('You Cancle Deletion')
    else:
       print('Invalid Type')
else:
    print('Book Does Not Exist')
    con.close()


