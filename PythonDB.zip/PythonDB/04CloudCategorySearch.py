import mysql.connector as m 

cat=input('Enter Category to Find : ')

con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
curs=con.cursor()

curs.execute("select * from books where Category='%s'" %cat)
data=curs.fetchall()
print(data)

con.close()