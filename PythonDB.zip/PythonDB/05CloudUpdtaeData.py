import mysql.connector as m 
con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
curs=con.cursor()

try:
    cod=int(input('Enter bookcode : '))
    curs.execute("select * from books where BookCode=%d" %cod)
    data=curs.fetchall()
    if data:
        amt=float(input('Enter amount ( Positive to Increase price) :'))
        curs.execute("update books set Price=Price+%.2f where BookCode=%d" %(amt,cod))
        con.commit()
        print('price changed')
    else:
        print('book not found')
except:
    print('error in update')

con.close()
