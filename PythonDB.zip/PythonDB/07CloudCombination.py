import mysql.connector as m 

au=input('Enter Book Author Name :')
pub=input('Enter Publication :')

con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
curs=con.cursor()

curs.execute("select BookName,CONCAT(Author,' & ',Publication) as Author_Publication from books")
data=curs.fetchall()
print(data)
con.close()
