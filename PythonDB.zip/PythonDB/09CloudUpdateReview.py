import mysql.connector as m 

cod=int(input('Enter Book Code To Fill Review :'))

con=m.connect(host='bh1tgfz4a34lvzhiuydr-mysql.services.clever-cloud.com',user='uxx7vnvuywb2dbmz',password='oSkRsoyG4HzGYk1QEKu2',database='bh1tgfz4a34lvzhiuydr')
curs=con.cursor()

rev=input('Here Enter Book Review :')
curs.execute("update books set Review=('%s') where BookCode=%d" %(rev,cod))
con.commit()
data=curs.fetchall()
print('Review is Inserted Successfully')
con.close()